Soul Land (ถังซาน) - Forge 1.12.2
build ด้วย GitHub: อัปโหลดไฟล์ทั้งหมด (รวมโฟลเดอร์ .github) ขึ้น repo ใหม่ -> แท็บ Actions -> รอจบ -> โหลด SoulLand-jar
คีย์: R = ใช้สกิล, V = สลับสกิล
