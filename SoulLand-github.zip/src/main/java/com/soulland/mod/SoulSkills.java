package com.soulland.mod;

import java.util.List;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import java.util.ArrayList;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.WorldServer;

public class SoulSkills {
    public static final int HAMMER = 1, GRASS = 2, TIGER = 4, RABBIT = 8;

    public static final class Skill {
        public final String key;
        public final int mask, ring, cost;
        Skill(String key, int mask, int ring, int cost) { this.key = key; this.mask = mask; this.ring = ring; this.cost = cost; }
    }

    /** ทักษะวิญญาณที่ N = ปลดล็อกด้วยวงแหวนวงที่ N */
    /** ทักษะวิญญาณที่ N = ปลดล็อกด้วยวงแหวนวงที่ N (หญ้าสีเงินคราม = ชุดทักษะของถังซาน) */
    public static final Skill[] ALL = {
        new Skill("bind", GRASS, 1, 10),      new Skill("smash", HAMMER, 1, 15),
        new Skill("parasite", GRASS, 2, 20),  new Skill("rage", HAMMER, 2, 20),
        new Skill("web", GRASS, 3, 30),       new Skill("quake", HAMMER, 3, 30),
        new Skill("cage", GRASS, 4, 40),      new Skill("leap", HAMMER, 4, 35),
        new Skill("spear", GRASS, 5, 50),     new Skill("wrath", HAMMER, 5, 60),
        new Skill("void", GRASS, 6, 70),      new Skill("thunder", HAMMER, 6, 70),
        new Skill("trueform", GRASS, 7, 90),  new Skill("gravity", HAMMER, 7, 80),
        new Skill("mirror", GRASS, 8, 110),   new Skill("titan", HAMMER, 8, 100),
        new Skill("tianxin", GRASS, 9, 150),  new Skill("judgement", HAMMER, 9, 150),
        // พยัคฆ์ขาว (สายสัตว์)
        new Skill("claw", TIGER, 1, 12),      new Skill("dash", TIGER, 2, 20),
        new Skill("roar", TIGER, 3, 35),      new Skill("pounce", TIGER, 4, 45),
        new Skill("tigerform", TIGER, 5, 80), new Skill("tigerwrath", TIGER, 6, 120),
        // กระต่ายกระดูกอ่อน (สายสัตว์)
        new Skill("kick", RABBIT, 1, 12),     new Skill("blink", RABBIT, 2, 20),
        new Skill("charm", RABBIT, 3, 35),    new Skill("rabbitrun", RABBIT, 4, 45),
        new Skill("spinkick", RABBIT, 5, 80), new Skill("queen", RABBIT, 6, 120)
    };

    public static boolean available(int soul, int rings, int idx) {
        if (idx < 0 || idx >= ALL.length) return false;
        Skill s = ALL[idx];
        return (soul & s.mask) != 0 && rings >= s.ring;
    }

    public static int next(int soul, int rings, int from) {
        for (int i = 1; i <= ALL.length; i++) {
            int j = (from + i + ALL.length) % ALL.length;
            if (available(soul, rings, j)) return j;
        }
        return -1;
    }

    private static void msg(EntityPlayerMP p, String key) {
        p.sendStatusMessage(new TextComponentTranslation(key), true);
    }

    public static void cycle(EntityPlayerMP p) {
        int n = next(SoulData.getSoul(p), SoulData.getRings(p), SoulData.getSelected(p));
        if (n < 0) { msg(p, "msg.soulland.noskill"); return; }
        SoulData.setSelected(p, n);
        SoulData.sync(p);
    }

    public static void toggleRelease(EntityPlayerMP p) {
        if (SoulData.getSoul(p) == 0) { msg(p, "msg.soulland.needawaken"); return; }
        NBTTagCompound t = SoulData.tag(p);
        boolean r = !t.getBoolean("released");
        t.setBoolean("released", r);
        WorldServer ws = (WorldServer) p.world;
        if (r) burst(ws, EnumParticleTypes.END_ROD, p.posX, p.posY + 1.0, p.posZ, 50, 0.6, 0.05);
        ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0F, r ? 1.4F : 0.7F);
        SoulData.syncVisual(p);
    }

    // ---------- ตัวช่วยเอฟเฟกต์ ----------
    private static List<EntityLivingBase> nearby(EntityPlayerMP p, double r) {
        return p.world.getEntitiesWithinAABB(EntityLivingBase.class, p.getEntityBoundingBox().grow(r),
                e -> e != p && e instanceof IMob && e.isEntityAlive());
    }

    private static void hit(EntityPlayerMP p, EntityLivingBase e, float dmg) {
        e.hurtResistantTime = 0;
        e.attackEntityFrom(DamageSource.causePlayerDamage(p), dmg);
    }

    private static void push(EntityPlayerMP p, EntityLivingBase e, float str) {
        e.knockBack(p, str, p.posX - e.posX, p.posZ - e.posZ);
    }

    private static void burst(WorldServer ws, EnumParticleTypes t, double x, double y, double z, int n, double spread, double speed) {
        ws.spawnParticle(t, x, y, z, n, spread, spread, spread, speed);
    }

    private static void circle(WorldServer ws, EnumParticleTypes t, double x, double y, double z, double r, int n) {
        for (int i = 0; i < n; i++) {
            double a = i * 2 * Math.PI / n;
            ws.spawnParticle(t, x + Math.cos(a) * r, y, z + Math.sin(a) * r, 1, 0, 0, 0, 0.0);
        }
    }

    /** วงคลื่นกระจายหลายชั้นบนพื้น */
    private static void waves(WorldServer ws, EnumParticleTypes t, EntityPlayerMP p, double max, double step) {
        for (double r = step; r <= max; r += step) circle(ws, t, p.posX, p.posY + 0.15, p.posZ, r, (int) (r * 9) + 8);
    }

    private static void spiral(WorldServer ws, EnumParticleTypes t, EntityPlayerMP p, double r, double h, int n) {
        for (int i = 0; i < n; i++) {
            double a = i * 0.45;
            ws.spawnParticle(t, p.posX + Math.cos(a) * r, p.posY + h * i / n, p.posZ + Math.sin(a) * r, 1, 0, 0, 0, 0.0);
        }
    }

    private static void bolt(WorldServer ws, double x, double y, double z) {
        ws.addWeatherEffect(new EntityLightningBolt(ws, x, y, z, true));
    }

    private static void fx(WorldServer ws, int type, double x, double y, double z, double x2, double y2, double z2, int dur, int ent) {
        NetworkHandler.CHANNEL.sendToAllAround(new PacketFx(type, x, y, z, x2, y2, z2, dur, ent),
                new NetworkRegistry.TargetPoint(ws.provider.getDimension(), x2 != 0 || y2 != 0 ? (x + x2) / 2 : x, y, z, 80));
    }

    private static void fxAt(WorldServer ws, EntityPlayerMP p, int type, double x, double y, double z, double x2, double y2, double z2, int dur, int ent) {
        NetworkHandler.CHANNEL.sendToAllAround(new PacketFx(type, x, y, z, x2, y2, z2, dur, ent),
                new NetworkRegistry.TargetPoint(ws.provider.getDimension(), p.posX, p.posY, p.posZ, 96));
    }

    public static void fxP(WorldServer ws, EntityPlayerMP p, int type, double x, double y, double z, double x2, double y2, double z2, int dur, int ent, int pal) {
        NetworkHandler.CHANNEL.sendToAllAround(new PacketFx(type, x, y, z, x2, y2, z2, dur, ent, pal),
                new NetworkRegistry.TargetPoint(ws.provider.getDimension(), p.posX, p.posY, p.posZ, 96));
    }

    private static Vec3d handPos(EntityPlayerMP p) {
        double yaw = Math.toRadians(p.rotationYaw);
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        return new Vec3d(p.posX - fz * 0.45 + fx * 0.5, p.posY + 1.05, p.posZ + fx * 0.45 + fz * 0.5);
    }

    private static List<EntityLivingBase> nearestEnemies(EntityPlayerMP p, double r) {
        List<EntityLivingBase> l = nearby(p, r);
        l.sort((a, b) -> Double.compare(a.getDistanceSq(p), b.getDistanceSq(p)));
        return l;
    }

    // ---------- ใช้สกิล ----------
    public static void cast(EntityPlayerMP p) {
        int soul = SoulData.getSoul(p), rings = SoulData.getRings(p), idx = SoulData.getSelected(p);
        if (soul == 0) return;
        if (!available(soul, rings, idx)) { msg(p, "msg.soulland.noskill"); return; }
        Skill s = ALL[idx];
        long now = p.world.getTotalWorldTime();
        NBTTagCompound t = SoulData.tag(p);
        if (now < t.getLong("cd")) return;
        int mana = SoulData.getMana(p);
        if (mana < s.cost) { msg(p, "msg.soulland.nomana"); return; }
        SoulData.setMana(p, mana - s.cost);
        if (!t.getBoolean("released")) { t.setBoolean("released", true); SoulData.syncVisual(p); }
        t.setLong("cd", now + 15);

        float mult = p.getHeldItemMainhand().getItem() == ModItems.HAMMER ? 1.5F : 1.0F;
        WorldServer ws = (WorldServer) p.world;
        double px = p.posX, py = p.posY, pz = p.posZ;
        ws.playSound(null, px, py, pz, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 0.8F, 0.6F);

        switch (s.key) {
            case "bind": {
                Vec3d h = handPos(p);
                int c = 0;
                for (EntityLivingBase e : nearestEnemies(p, 9)) {
                    if (c++ >= 4) break;
                    hit(p, e, 5);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 60, 6));
                    fxAt(ws, p, 1, h.x, h.y, h.z, 0, 0, 0, 60, e.getEntityId());
                }
                break;
            }
            case "parasite": {
                int c = 0;
                for (EntityLivingBase e : nearestEnemies(p, 10)) {
                    if (c++ >= 3) break;
                    final EntityLivingBase tg = e;
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 100, 6));
                    e.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 100, 1));
                    fxAt(ws, p, 2, 0, 0, 0, 0, 0, 0, 100, e.getEntityId());
                    Tasks.add(new Tasks.Task(100) {
                        @Override public void tick(int a) {
                            if (a % 10 == 5 && tg.isEntityAlive()) { hit(p, tg, 3); p.heal(1); }
                        }
                    });
                }
                break;
            }
            case "web": {
                Vec3d eye = p.getPositionEyes(1.0F), look = p.getLookVec();
                Vec3d to = eye.add(look.x * 14, look.y * 14, look.z * 14);
                RayTraceResult rt = ws.rayTraceBlocks(eye, to, false, true, false);
                Vec3d end = rt != null ? rt.hitVec : to;
                double best = 1e9;
                for (EntityLivingBase e : nearby(p, 14)) {
                    Vec3d ec = new Vec3d(e.posX, e.posY + e.height / 2, e.posZ);
                    Vec3d rel = ec.subtract(eye);
                    double proj = rel.dotProduct(look);
                    if (proj < 0 || proj > 14) continue;
                    Vec3d perp = rel.subtract(look.x * proj, look.y * proj, look.z * proj);
                    if (perp.length() < 1.3 && proj < best) { best = proj; end = ec; }
                }
                final Vec3d ep = end;
                Vec3d h = handPos(p);
                fxAt(ws, p, 3, h.x, h.y, h.z, ep.x, ep.y, ep.z, 60, -1);
                Tasks.add(new Tasks.Task(10) {
                    @Override public void end() {
                        for (EntityLivingBase e : ws.getEntitiesWithinAABB(EntityLivingBase.class,
                                new AxisAlignedBB(ep.x - 5, ep.y - 5, ep.z - 5, ep.x + 5, ep.y + 5, ep.z + 5),
                                en -> en != p && en instanceof IMob && en.isEntityAlive())) {
                            hit(p, e, 8);
                            e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 80, 6));
                        }
                    }
                });
                break;
            }
            case "cage": {
                List<EntityLivingBase> l = nearestEnemies(p, 12);
                double cx, cy, cz;
                if (!l.isEmpty()) { cx = l.get(0).posX; cy = l.get(0).posY; cz = l.get(0).posZ; }
                else { Vec3d look = p.getLookVec(); cx = px + look.x * 6; cy = py; cz = pz + look.z * 6; }
                final double fcx = cx, fcy = cy, fcz = cz, R = 3.0;
                final List<EntityLivingBase> trapped = new ArrayList<>();
                for (EntityLivingBase e : nearby(p, 20))
                    if (Math.hypot(e.posX - fcx, e.posZ - fcz) <= R + 0.8 && Math.abs(e.posY - fcy) < 4) trapped.add(e);
                fxAt(ws, p, 4, fcx, fcy, fcz, R, 3.5, 0, 100, -1);
                Tasks.add(new Tasks.Task(100) {
                    @Override public void tick(int a) {
                        for (EntityLivingBase tg : trapped) {
                            if (!tg.isEntityAlive()) continue;
                            double dx = tg.posX - fcx, dz = tg.posZ - fcz, d = Math.sqrt(dx * dx + dz * dz);
                            if (d > R - 0.5) { double k = (R - 0.6) / d; tg.setPositionAndUpdate(fcx + dx * k, tg.posY, fcz + dz * k); }
                            tg.motionX *= 0.1; tg.motionZ *= 0.1;
                            if (a % 10 == 0) { tg.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 20, 6)); hit(p, tg, 2); }
                        }
                    }
                });
                break;
            }
            case "spear": {
                Vec3d eye = p.getPositionEyes(1.0F), look = p.getLookVec();
                Vec3d to = eye.add(look.x * 16, look.y * 16, look.z * 16);
                RayTraceResult rt = ws.rayTraceBlocks(eye, to, false, true, false);
                Vec3d end = rt != null ? rt.hitVec : to;
                double len = end.distanceTo(eye);
                for (EntityLivingBase e : nearby(p, 18)) {
                    Vec3d rel = new Vec3d(e.posX - eye.x, e.posY + e.height / 2 - eye.y, e.posZ - eye.z);
                    double proj = rel.dotProduct(look);
                    if (proj < 0 || proj > len + 0.5) continue;
                    Vec3d perp = rel.subtract(look.x * proj, look.y * proj, look.z * proj);
                    if (perp.length() < 1.4) {
                        hit(p, e, 35); push(p, e, 2.0F);
                        burst(ws, EnumParticleTypes.CRIT_MAGIC, e.posX, e.posY + 1, e.posZ, 20, 0.3, 0.1);
                    }
                }
                Vec3d h = handPos(p);
                fxAt(ws, p, 5, h.x, h.y, h.z, end.x, end.y, end.z, 12, -1);
                break;
            }
            case "void":
                t.setLong("voidUntil", now + 100);
                p.addPotionEffect(new PotionEffect(MobEffects.SPEED, 100, 1));
                fxAt(ws, p, 6, 0, 0, 0, 0, 0, 0, 100, p.getEntityId());
                break;
            case "trueform":
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 400, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.SPEED, 400, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 400, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 400, 0));
                p.addPotionEffect(new PotionEffect(MobEffects.ABSORPTION, 400, 2));
                fxAt(ws, p, 7, 0, 0, 0, 0, 0, 0, 400, p.getEntityId());
                break;
            case "mirror":
                fxAt(ws, p, 8, 0, 0, 0, 0, 0, 0, 80, p.getEntityId());
                Tasks.add(new Tasks.Task(80) {
                    @Override public void tick(int a) {
                        if (a % 5 != 0 || !p.isEntityAlive()) return;
                        for (EntityLivingBase e : nearby(p, 6)) {
                            hit(p, e, 10);
                            e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 20, 2));
                        }
                    }
                });
                break;
            case "tianxin": {
                Vec3d look = p.getLookVec();
                double lx = look.x, lz = look.z, ll = Math.sqrt(lx * lx + lz * lz);
                if (ll < 1e-4) { lx = 0; lz = 1; } else { lx /= ll; lz /= ll; }
                final double sx = px + lx * 2, sz = pz + lz * 2, ex = sx + lx * 14, ez = sz + lz * 14, sy = py;
                fxAt(ws, p, 9, sx, sy, sz, ex, sy, ez, 60, -1);
                Tasks.add(new Tasks.Task(60) {
                    @Override public void tick(int a) {
                        if (a % 3 != 0) return;
                        double g = a / 60.0, cx = sx + (ex - sx) * g, cz = sz + (ez - sz) * g;
                        for (EntityLivingBase e : ws.getEntitiesWithinAABB(EntityLivingBase.class,
                                new AxisAlignedBB(cx - 4, sy - 1, cz - 4, cx + 4, sy + 5, cz + 4),
                                en -> en != p && en instanceof IMob && en.isEntityAlive())) {
                            hit(p, e, 12);
                            e.motionY = 0.5; e.motionX += (cx - e.posX) * 0.2; e.motionZ += (cz - e.posZ) * 0.2;
                            e.velocityChanged = true;
                            e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 20, 1));
                        }
                    }
                });
                break;
            }
            case "smash":
                for (EntityLivingBase e : nearby(p, 4)) { hit(p, e, 8 * mult); push(p, e, 1.5F); }
                waves(ws, EnumParticleTypes.CLOUD, p, 4, 1.0);
                burst(ws, EnumParticleTypes.EXPLOSION_LARGE, px, py + 0.3, pz, 4, 1.2, 0.0);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.6F, 1.2F);
                break;
            case "rage":
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 600, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 600, 0));
                spiral(ws, EnumParticleTypes.FLAME, p, 0.8, 2.2, 60);
                break;
            case "quake":
                for (EntityLivingBase e : nearby(p, 6)) {
                    hit(p, e, 14 * mult);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 60, 1));
                    e.motionY = 0.6; e.velocityChanged = true;
                }
                waves(ws, EnumParticleTypes.SMOKE_LARGE, p, 6, 1.0);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.8F, 0.7F);
                break;
            case "leap": {
                Vec3d look = p.getLookVec();
                p.motionX = look.x * 1.4; p.motionY = 0.9; p.motionZ = look.z * 1.4;
                p.velocityChanged = true;
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 100, 4));
                waves(ws, EnumParticleTypes.CLOUD, p, 3, 1.0);
                break;
            }
            case "wrath":
                for (EntityLivingBase e : nearby(p, 8)) { hit(p, e, 25 * mult); push(p, e, 2.0F); }
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 200, 2));
                waves(ws, EnumParticleTypes.FLAME, p, 8, 2.0);
                burst(ws, EnumParticleTypes.EXPLOSION_HUGE, px, py + 0.5, pz, 3, 2.0, 0.0);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.0F, 0.6F);
                break;
            case "thunder": {
                List<EntityLivingBase> l = nearby(p, 14);
                l.sort((a, b) -> Double.compare(a.getDistanceSq(p), b.getDistanceSq(p)));
                int c = 0;
                for (EntityLivingBase e : l) {
                    if (c++ >= 6) break;
                    bolt(ws, e.posX, e.posY, e.posZ);
                    hit(p, e, 22 * mult);
                    burst(ws, EnumParticleTypes.FLAME, e.posX, e.posY + 1, e.posZ, 30, 0.4, 0.05);
                }
                waves(ws, EnumParticleTypes.CRIT_MAGIC, p, 6, 2.0);
                break;
            }
            case "gravity":
                for (EntityLivingBase e : nearby(p, 10)) {
                    hit(p, e, 8 * mult);
                    Vec3d d = new Vec3d(px - e.posX, py - e.posY, pz - e.posZ).normalize();
                    e.motionX += d.x * 1.2; e.motionY += d.y * 0.5 + 0.2; e.motionZ += d.z * 1.2;
                    e.velocityChanged = true;
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 60, 2));
                }
                spiral(ws, EnumParticleTypes.PORTAL, p, 2.5, 3.0, 100);
                waves(ws, EnumParticleTypes.PORTAL, p, 10, 2.5);
                break;
            case "titan":
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 400, 3));
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 400, 2));
                p.addPotionEffect(new PotionEffect(MobEffects.ABSORPTION, 400, 4));
                for (EntityLivingBase e : nearby(p, 6)) { hit(p, e, 20 * mult); push(p, e, 2.0F); }
                spiral(ws, EnumParticleTypes.FLAME, p, 1.2, 3.5, 100);
                waves(ws, EnumParticleTypes.CLOUD, p, 6, 1.5);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.0F, 0.5F);
                break;
            case "judgement": {
                List<EntityLivingBase> l = nearby(p, 14);
                int c = 0;
                for (EntityLivingBase e : l) {
                    hit(p, e, 60 * mult);
                    push(p, e, 2.5F);
                    if (c++ < 8) bolt(ws, e.posX, e.posY, e.posZ);
                }
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 200, 3));
                waves(ws, EnumParticleTypes.FLAME, p, 14, 2.0);
                burst(ws, EnumParticleTypes.EXPLOSION_HUGE, px, py + 0.5, pz, 5, 3.0, 0.0);
                spiral(ws, EnumParticleTypes.FLAME, p, 2.0, 6.0, 120);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.2F, 0.5F);
                break;
            }
            case "claw": {
                Vec3d look = p.getLookVec();
                double lx = look.x, lz = look.z, ll = Math.sqrt(lx * lx + lz * lz);
                if (ll < 1e-4) { lx = 0; lz = 1; } else { lx /= ll; lz /= ll; }
                for (EntityLivingBase e : nearby(p, 5)) {
                    Vec3d rel = new Vec3d(e.posX - px, 0, e.posZ - pz);
                    if (rel.length() > 5 || rel.length() < 1e-4) continue;
                    if (rel.normalize().dotProduct(new Vec3d(lx, 0, lz)) > 0.4) { hit(p, e, 12); push(p, e, 0.8F); }
                }
                fxP(ws, p, 11, px + lx * 1.6, py + 1.2, pz + lz * 1.6, lx * 2.2, 0, lz * 2.2, 10, -1, 3);
                break;
            }
            case "dash": {
                Vec3d look = p.getLookVec();
                double lx = look.x, lz = look.z, ll = Math.sqrt(lx * lx + lz * lz);
                if (ll < 1e-4) { lx = 0; lz = 1; } else { lx /= ll; lz /= ll; }
                for (EntityLivingBase e : nearby(p, 9)) {
                    double rx = e.posX - px, rz = e.posZ - pz, proj = rx * lx + rz * lz, perp = Math.abs(-rx * lz + rz * lx);
                    if (proj >= 0 && proj <= 7 && perp < 1.6) { hit(p, e, 15); push(p, e, 1.0F); }
                }
                p.motionX = lx * 2.2; p.motionZ = lz * 2.2; p.motionY = 0.1; p.velocityChanged = true;
                fxP(ws, p, 13, px, py + 0.8, pz, px + lx * 7, py + 0.8, pz + lz * 7, 14, -1, 3);
                break;
            }
            case "roar":
                for (EntityLivingBase e : nearby(p, 8)) {
                    hit(p, e, 10); push(p, e, 1.8F);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 100, 1));
                    e.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 100, 1));
                }
                fxP(ws, p, 12, px, py, pz, 8, 0, 0, 16, -1, 3);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.8F, 0.6F);
                break;
            case "pounce": {
                Vec3d look = p.getLookVec();
                double lx = look.x, lz = look.z, ll = Math.sqrt(lx * lx + lz * lz);
                if (ll < 1e-4) { lx = 0; lz = 1; } else { lx /= ll; lz /= ll; }
                p.motionX = lx * 1.1; p.motionY = 0.9; p.motionZ = lz * 1.1; p.velocityChanged = true;
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 40, 4));
                Tasks.add(new Tasks.Task(16) {
                    @Override public void end() {
                        for (EntityLivingBase e : nearby(p, 5)) { hit(p, e, 30); push(p, e, 1.5F); }
                        fxP(ws, p, 12, p.posX, p.posY, p.posZ, 5, 0, 0, 14, -1, 3);
                        burst(ws, EnumParticleTypes.EXPLOSION_LARGE, p.posX, p.posY + 0.3, p.posZ, 3, 1.2, 0.0);
                        ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.8F, 0.9F);
                    }
                });
                break;
            }
            case "tigerform":
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 500, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.SPEED, 500, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 500, 0));
                p.addPotionEffect(new PotionEffect(MobEffects.JUMP_BOOST, 500, 1));
                fxP(ws, p, 14, 0, 0, 0, 0, 0, 0, 500, p.getEntityId(), 3);
                break;
            case "tigerwrath": {
                Vec3d look = p.getLookVec();
                double lx = look.x, lz = look.z, ll = Math.sqrt(lx * lx + lz * lz);
                if (ll < 1e-4) { lx = 0; lz = 1; } else { lx /= ll; lz /= ll; }
                final double fx = lx, fz = lz;
                Tasks.add(new Tasks.Task(12) {
                    @Override public void tick(int a) {
                        if (a % 4 != 0) return;
                        fxP(ws, p, 11, p.posX + fx * 3.5, p.posY + 1.3, p.posZ + fz * 3.5, fx * 5.5, 0, fz * 5.5, 12, -1, 3);
                        for (EntityLivingBase e : nearby(p, 13)) {
                            double rx = e.posX - p.posX, rz = e.posZ - p.posZ, proj = rx * fx + rz * fz, perp = Math.abs(-rx * fz + rz * fx);
                            if (proj >= 0 && proj <= 12 && perp < 3.5) { hit(p, e, 20); push(p, e, 1.2F); }
                        }
                        ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.6F, 1.4F);
                    }
                });
                break;
            }
            case "kick": {
                List<EntityLivingBase> l = nearestEnemies(p, 5);
                if (!l.isEmpty()) {
                    EntityLivingBase e = l.get(0);
                    hit(p, e, 12); push(p, e, 1.5F);
                    fxP(ws, p, 13, px, py + 0.9, pz, e.posX, e.posY + 0.9, e.posZ, 10, -1, 1);
                    fxP(ws, p, 11, e.posX, e.posY + 1.0, e.posZ, 1.6, 0, 0, 8, -1, 1);
                }
                break;
            }
            case "blink": {
                Vec3d eye = p.getPositionEyes(1.0F), look = p.getLookVec();
                Vec3d to = eye.add(look.x * 8, look.y * 8, look.z * 8);
                RayTraceResult rt = ws.rayTraceBlocks(eye, to, false, true, false);
                Vec3d dest = rt != null ? rt.hitVec.subtract(look.x * 0.6, look.y * 0.6, look.z * 0.6) : to;
                fxP(ws, p, 13, px, py + 0.8, pz, dest.x, dest.y - p.getEyeHeight() + 0.8, dest.z, 12, -1, 1);
                burst(ws, EnumParticleTypes.END_ROD, px, py + 1, pz, 25, 0.4, 0.05);
                p.setPositionAndUpdate(dest.x, dest.y - p.getEyeHeight(), dest.z);
                burst(ws, EnumParticleTypes.END_ROD, dest.x, dest.y, dest.z, 25, 0.4, 0.05);
                t.setLong("voidUntil", now + 25);
                break;
            }
            case "charm":
                for (EntityLivingBase e : nearby(p, 8)) {
                    hit(p, e, 5);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 100, 2));
                    e.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 100, 1));
                    e.addPotionEffect(new PotionEffect(MobEffects.GLOWING, 100, 0));
                    burst(ws, EnumParticleTypes.HEART, e.posX, e.posY + 1.5, e.posZ, 5, 0.3, 0.02);
                }
                p.addPotionEffect(new PotionEffect(MobEffects.SPEED, 100, 1));
                fxP(ws, p, 12, px, py, pz, 8, 0, 0, 16, -1, 1);
                break;
            case "rabbitrun":
                p.addPotionEffect(new PotionEffect(MobEffects.SPEED, 120, 3));
                p.addPotionEffect(new PotionEffect(MobEffects.JUMP_BOOST, 120, 2));
                fxP(ws, p, 14, 0, 0, 0, 0, 0, 0, 120, p.getEntityId(), 1);
                break;
            case "spinkick":
                Tasks.add(new Tasks.Task(20) {
                    @Override public void tick(int a) {
                        if (a % 4 != 0 || !p.isEntityAlive()) return;
                        for (EntityLivingBase e : nearby(p, 5)) { hit(p, e, 9); push(p, e, 1.2F); }
                        fxP(ws, p, 12, p.posX, p.posY, p.posZ, 5, 0, 0, 8, -1, 1);
                    }
                });
                break;
            case "queen": {
                List<EntityLivingBase> l = nearestEnemies(p, 14);
                if (l.isEmpty()) break;
                final EntityLivingBase tg = l.get(0);
                double dx = tg.posX - px, dz = tg.posZ - pz, dl = Math.sqrt(dx * dx + dz * dz);
                if (dl < 1e-4) { dx = 0; dz = 1; dl = 1; }
                fxP(ws, p, 13, px, py + 0.8, pz, tg.posX, tg.posY + 0.8, tg.posZ, 12, -1, 1);
                p.setPositionAndUpdate(tg.posX + dx / dl * 1.5, tg.posY, tg.posZ + dz / dl * 1.5);
                t.setLong("voidUntil", now + 40);
                Tasks.add(new Tasks.Task(30) {
                    @Override public void tick(int a) {
                        if (a % 5 != 0 || !tg.isEntityAlive()) return;
                        hit(p, tg, 16); push(p, tg, 0.5F);
                        double ang = a * 1.3;
                        fxP(ws, p, 11, tg.posX, tg.posY + 1.0, tg.posZ, Math.cos(ang) * 2.2, 0, Math.sin(ang) * 2.2, 8, -1, 1);
                        for (EntityLivingBase e : ws.getEntitiesWithinAABB(EntityLivingBase.class,
                                new AxisAlignedBB(tg.posX - 4, tg.posY - 2, tg.posZ - 4, tg.posX + 4, tg.posY + 3, tg.posZ + 4),
                                en -> en != p && en != tg && en instanceof IMob && en.isEntityAlive())) hit(p, e, 8);
                    }
                });
                break;
            }
            default: break;
        }
        SoulData.sync(p);
    }
}
