package com.soulland.mod;

import java.util.ArrayList;
import java.util.List;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** งานที่ทำงานต่อเนื่องหลายทิคฝั่งเซิร์ฟเวอร์ (ดาเมจต่อเนื่อง กรงขัง พายุ ฯลฯ) */
@Mod.EventBusSubscriber(modid = SoulLand.MODID)
public class Tasks {
    public abstract static class Task {
        public int age;
        public final int dur;
        public Task(int dur) { this.dur = dur; }
        public void tick(int age) {}
        public void end() {}
    }

    private static final List<Task> LIST = new ArrayList<>();

    public static void add(Task t) { LIST.add(t); }

    @SubscribeEvent
    public static void serverTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || LIST.isEmpty()) return;
        for (Task t : new ArrayList<>(LIST)) {
            try {
                t.tick(t.age);
                t.age++;
                if (t.age >= t.dur) { t.end(); LIST.remove(t); }
            } catch (Throwable ex) {
                LIST.remove(t);
            }
        }
    }
}
