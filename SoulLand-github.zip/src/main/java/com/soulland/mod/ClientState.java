package com.soulland.mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ClientState {
    public static int soul, level, exp, rings, mana, selected;

    public static final Map<UUID, Visual> visuals = new HashMap<>();
    public static final Map<Integer, int[]> mobRings = new HashMap<>();

    public static class Visual {
        public final int soul;
        public final boolean released;
        public final int[] tiers;
        public final int abTier, abProgress;

        public Visual(int soul, boolean released, int[] tiers, int abTier, int abProgress) {
            this.soul = soul; this.released = released; this.tiers = tiers;
            this.abTier = abTier; this.abProgress = abProgress;
        }
    }
}
