package com.soulland.mod;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;

/** ลูกแก้วปลุกวิญญาณยุทธ์ */
public class ItemSoulOrb extends Item {
    public ItemSoulOrb() { setMaxStackSize(16); }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World w, EntityPlayer p, EnumHand h) {
        ItemStack s = p.getHeldItem(h);
        if (!w.isRemote) {
            EntityPlayerMP mp = (EntityPlayerMP) p;
            if (!Awaken.start(mp, false)) return new ActionResult<>(EnumActionResult.FAIL, s);
            if (!p.capabilities.isCreativeMode) s.shrink(1);
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, s);
    }
}
